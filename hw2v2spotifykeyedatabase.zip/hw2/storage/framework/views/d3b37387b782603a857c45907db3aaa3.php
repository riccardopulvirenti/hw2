
<?php $__env->startSection('title','Just Eat | Ristoranti'); ?>

<?php $__env->startSection('content'); ?>
<div>
    <form method="POST" action="<?php echo e(route('cercaristoranti')); ?>" id="form_filtri">
        <?php echo csrf_field(); ?>
        <div>
            <label>Seleziona una Regione :</label>
            <select id="scelta_regione" name="regione_id" required onchange="this.form.submit()">
                <option value="" disabled <?php echo e(old('regione_id', $selectedRegione ?? '') == '' ? 'selected' : ''); ?>>Scegli una Regione</option>
                <?php $__currentLoopData = $regioni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($regione->id_regione); ?>"
                        <?php echo e(old('regione_id', $selectedRegione ?? '') == $regione->id_regione ? 'selected' : ''); ?>>
                        <?php echo e($regione->nome_regione); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        
        <div>
            <label>Seleziona una Provincia:</label>
            <select name="provincia" id="scelta_provincia" required onchange="this.form.submit()">
                <option value="" disabled <?php echo e(old('provincia', $selectedProvincia ?? '') == '' ? 'selected' : ''); ?>>Scegli una Provincia</option>
                <?php if(!empty($province)): ?>
                    <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($provincia->nome_provincia); ?>"
                            <?php echo e(old('provincia', $selectedProvincia ?? '') == $provincia->nome_provincia ? 'selected' : ''); ?>>
                            <?php echo e($provincia->nome_provincia); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
        <div>
            <label>Seleziona il numero di stelle:</label>
            <select name="stelle" id="scelta_stelle" required onchange="this.form.submit()">
                <option value="" disabled hidden <?php echo e(old('stelle', $selectedStelle ?? '') == '' ? 'selected' : ''); ?>>Seleziona le stelle del ristorante</option>
                <?php for($i = 1; $i <= 5; $i++): ?>
                    <option value="<?php echo e($i); ?>" <?php echo e(old('stelle', $selectedStelle ?? '') == $i ? 'selected' : ''); ?>>
                        <?php echo e($i); ?> Stelle
                    </option>
                <?php endfor; ?>
            </select>
        </div>
        <div>
            
        </div>

    </form>
    <form method="GET" action="<?php echo e(url('ristoranti')); ?>">
        <button type="submit">Resetta filtri</button>
    </form>
    <div id="divcontenitoreristoranti">
        <?php $__currentLoopData = $ristoranti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ristorante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('ristorante.mostra', ['id' => $ristorante->id_ristorante])); ?>" data-id_ristorante="<?php echo e($ristorante->id_ristorante); ?>">
                <h3><?php echo e($ristorante->nome_ristorante); ?></h3>
                <p><?php echo e($ristorante->tipologia_ristorante); ?></p>
                <p><?php echo e($ristorante->provincia_ristorante); ?></p>
                <div>
                    <?php for($i = 0; $i < $ristorante->stelle_ristorante; $i++): ?>
                        <span>★</span>
                    <?php endfor; ?>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/ristoranti.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\anima\Desktop\hw2\resources\views/ristoranti.blade.php ENDPATH**/ ?>