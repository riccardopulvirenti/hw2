
<form id="logout-form" action="/logout" method="POST">
    <?php echo csrf_field(); ?>
</form>

<script>
    document.getElementById('logout-form').submit();
</script>
<?php /**PATH C:\Users\Ricky\Desktop\hw2\resources\views/logout.blade.php ENDPATH**/ ?>