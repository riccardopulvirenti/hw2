

<?php $__env->startSection('title', 'Il tuo carrello'); ?>

<?php $__env->startSection('content'); ?>
    <div id="contenuto_carrello">
        <?php $totale = 0; ?>

        <?php $__currentLoopData = $carrello; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elemento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="divcontenitore" data-id_piatto="<?php echo e($elemento['id_piatto']); ?>" data-id_ristorante="<?php echo e($elemento['id_ristorante']); ?>">
                <div class="divtesto">
                    <p><?php echo e($elemento['nome_piatto']); ?></p>
                    <p><?php echo e($elemento['nome_ristorante']); ?></p>
                    <p><?php echo e(number_format($elemento['prezzo'], 2, ',', '.')); ?>€</p>
                </div>

                <div class="divrimuovielemento">
                    <form method="POST" action="<?php echo e(route('rimuovidalcarrello')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id_piatto" value="<?php echo e($elemento['id_piatto']); ?>">
                        <input type="hidden" name="id_ristorante" value="<?php echo e($elemento['id_ristorante']); ?>">
                        <button type="submit" class="btn-rimuovi">
                            <img src="<?php echo e(asset('svg/close.svg')); ?>" alt="Rimuovi">
                        </button>
                    </form>
                </div>
            </div>

            <?php $totale += $elemento['prezzo']; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <hr>

        <div id="testototale">
            <strong>Totale: <?php echo e(number_format($totale, 2, ',', '.')); ?>€</strong>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/carrello.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\anima\Desktop\hw2\resources\views/carrello.blade.php ENDPATH**/ ?>