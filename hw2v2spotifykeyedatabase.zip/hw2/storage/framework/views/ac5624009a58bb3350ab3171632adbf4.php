
<?php $__env->startSection('title','Just Eat | Informazioni utente'); ?>

<?php $__env->startSection('content'); ?>
    <div id="contenuto_info">
        <form method="POST" action="<?php echo e(route('aggiornainfoutente')); ?>">
            <?php echo csrf_field(); ?>
            <div>
                <label>Nome:</label>
                <input type="text" id="nome" name="nome" value="<?php echo e(old('nome', $informazioniutente->nome ?? '')); ?>">
            </div>
            <div>
                <label>Cognome:</label>
                <input type="text" id="cognome" name="cognome" value="<?php echo e(old('cognome', $informazioniutente->cognome ?? '')); ?>">
            </div>
            <div>
                <label>Sesso:</label>
                <label>
                    <input type="radio" name="sesso" value="M" required id="maschio"
                        <?php echo e((isset($informazioniutente) && $informazioniutente->sesso === 'M') ? 'checked' : ''); ?>>
                    Maschio
                </label>

                <label>
                    <input type="radio" name="sesso" value="F" required id="femmina"
                        <?php echo e((isset($informazioniutente) && $informazioniutente->sesso === 'F') ? 'checked' : ''); ?>>
                    Femmina
                </label>
            </div>
            <div>
                <label>Data di Nascita:</label>
                <input type="date" id="data_di_nascita" name="data_di_nascita" value="<?php echo e(old('data_di_nascita', $informazioniutente->data_di_nascita ?? '')); ?>">
            </div>
            <div>
                <label>Numero di Telefono:</label>
                <input type="text" id="numero_di_telefono" name="numero_telefono" value="<?php echo e(old('numero_telefono', $informazioniutente->numero_telefono ?? '')); ?>">
            </div>
            <p id="status"></p>
            <div>
                <button type="submit">Aggiorna</button>
            </div>
            
        </form>
        <div>
            <?php if(session('success')): ?>
                <p>
                    <?php echo e(session('success')); ?>

                </p>
            <?php endif; ?>
        </div>
        

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/informazioni_utente.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ricky\Desktop\hw2\resources\views/informazioni_utente.blade.php ENDPATH**/ ?>