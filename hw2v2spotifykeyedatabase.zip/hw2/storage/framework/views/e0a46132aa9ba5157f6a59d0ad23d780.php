
<?php $__env->startSection('title','Just Eat | Piatti Preferiti'); ?>
<?php $__env->startSection('content'); ?>
    <div id="piatti_preferiti">
        <?php if(isset($cibi) && count($cibi) > 0): ?>
            <?php $__currentLoopData = $cibi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cibo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <img src="<?php echo e($cibo['image_url']); ?>" data-idMeal="<?php echo e($cibo['idMeal']); ?>">
                    <span><?php echo e($cibo['nome_piatto']); ?></span>
                    <img src="<?php echo e(asset('svg/close.svg')); ?>" onclick="rimuovipreferito(event)" class="stellapreferiti">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <p>Non ci sono piatti preferiti</p>
        <?php endif; ?>
    </div>
          
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script defer src="<?php echo e(asset('js/piattipreferiti.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/piattipreferiti.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ricky\Desktop\hw2\resources\views/piattipreferiti.blade.php ENDPATH**/ ?>