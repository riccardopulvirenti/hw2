
<?php $__env->startSection('title','Just Eat | Cerca Cibo'); ?>
<?php $__env->startSection('content'); ?>
    <section id="cercacibo">
        <div id="formricerca">
            <div>
                <span>Scatena il tuo languorino con le foto dei nostri piatti!</span>
                <form id="formricercapiatto" action="/api/cercacibo" method="POST" name="cercacibo">
                <?php echo csrf_field(); ?>
                    <input type="text" id="nomepiatto" value="Cerca il tuo piatto preferito!" required name="nomepiatto">
                    <button type="submit">Cerca</button>
                </form>
                
            </div>
            
        </div>
        <div id="fotocibo">
            <?php if(isset($cibi)): ?>
                <?php $__currentLoopData = $cibi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cibo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <img src="<?php echo e($cibo['strMealThumb']); ?>" data-idMeal=<?php echo e($cibo['idMeal']); ?>>
                        <span><?php echo e($cibo['strMeal']); ?></span>
                        <?php if(session()->has('email_utente')): ?>
                            <?php if(in_array($cibo['idMeal'], $piattipreferiti ?? [])): ?>
                                <img src="<?php echo e(asset('svg/favourite.svg')); ?>" onclick="rimuovipiatto(event)" class="stellapreferiti">
                            <?php else: ?>
                                <img src="<?php echo e(asset('svg/unfavourite.svg')); ?>" onclick="aggiungipiatto(event)" class="stellapreferiti">
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script defer src="<?php echo e(asset('js/cercacibo.js')); ?>"></script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ricky\Desktop\hw2\resources\views/cercacibo.blade.php ENDPATH**/ ?>