<?php $__env->startSection('title','Just Eat | Consegna a domicilio: ordina cibo e spesa online'); ?>

<?php $__env->startSection('content'); ?>
    <div id="spotify_integration">
        <div id="spotifymenu" class="hide">
        </div>
        <div id="spotifybar">
            <img src="<?php echo e(asset('svg/spotify.svg')); ?>" alt="">
            <span>Il mood giusto per il tuo pasto!</span>
        </div>
    </div>
    <div id="menuacomparsacontainer" class="sotterrato">
        <div id="menuacomparsa">
            <div id="divmenusuperiore">
                <div>
                    <svg width="1em" height="1em" aria-hidden="true" viewBox="0 0 16 16"><path d="M12.646 2.969H3.354L1.219 5.104v5.792l2.135 2.135h9.292l2.135-2.135V5.104zm.823 7.385-1.365 1.365H3.896l-1.365-1.365V5.646l1.365-1.365h8.208l1.365 1.365zm-2.844-3.798L9.242 6.25l-.665-1.225a.69.69 0 0 0-1.154 0L6.758 6.25l-1.383.306a.65.65 0 0 0-.499.455.66.66 0 0 0 .167.657l.953.97-.201 1.427a.665.665 0 0 0 .954.674L8 10.1l1.251.639a.63.63 0 0 0 .306.07.6.6 0 0 0 .377-.123.64.64 0 0 0 .271-.621l-.201-1.426.971-.971a.657.657 0 0 0-.35-1.112m-1.75 1.391a.64.64 0 0 0-.184.552l.07.498-.437-.218a.67.67 0 0 0-.595 0l-.438.219.07-.5a.64.64 0 0 0-.236-.55l-.332-.342.498-.096a.64.64 0 0 0 .446-.332L8 6.748l.236.43a.64.64 0 0 0 .446.332l.5.096z"/></svg>
                    <p>Premi</p>
                </div>
                <div>
                    <svg width="1em" height="1em" aria-hidden="true" viewBox="0 0 16 16"><path d="M13.941 10.039c-.043.061-.183.254-.218.332a3 3 0 0 0-.105.473c-.097.569-.22 1.338-.832 1.951-.603.604-1.4.735-1.925.822-.157.027-.393.062-.49.105-.07.027-.27.176-.376.245-.437.324-1.111.806-1.995.806s-1.549-.482-1.986-.806a4 4 0 0 0-.376-.253c-.088-.035-.315-.07-.473-.105-.542-.088-1.339-.219-1.942-.832-.604-.603-.735-1.373-.823-1.933-.035-.201-.061-.403-.105-.49-.026-.07-.166-.254-.245-.368-.324-.446-.814-1.12-.814-2.004s.482-1.548.805-1.986c.07-.096.22-.306.254-.376.035-.096.079-.324.105-.481v-.062c.096-.524.245-1.294.831-1.88.587-.587 1.374-.736 1.934-.823.166-.026.394-.062.49-.105.07-.026.271-.175.376-.245.473-.341 1.112-.805 1.995-.805.884 0 1.55.481 1.987.805.122.087.306.227.376.253a3 3 0 0 0 .481.105c.569.097 1.339.22 1.943.832.603.612.735 1.374.822 1.933.026.158.061.394.105.49.026.07.166.254.245.368.35.481.814 1.12.814 2.004s-.481 1.548-.805 1.986zM3.695 5.419a3.3 3.3 0 0 1-.175.726 3.4 3.4 0 0 1-.411.656c-.263.368-.543.753-.543 1.199s.28.831.552 1.207c.157.22.315.438.402.648.096.227.14.49.184.77.079.455.149.919.455 1.216.306.298.779.385 1.207.455.28.044.552.088.78.184.2.088.393.219.655.402.368.272.753.543 1.2.543.445 0 .83-.28 1.207-.551.2-.149.428-.315.647-.403.236-.096.525-.149.788-.184.42-.07.9-.148 1.198-.446.307-.306.377-.761.455-1.207.044-.271.088-.552.184-.779.079-.201.219-.402.368-.604l.035-.052c.27-.377.55-.753.55-1.199s-.28-.831-.542-1.199c-.157-.219-.315-.437-.402-.656-.096-.236-.149-.534-.184-.787-.07-.438-.149-.902-.446-1.2-.298-.306-.761-.376-1.208-.454-.27-.044-.55-.088-.787-.193-.21-.087-.438-.245-.648-.402-.376-.272-.76-.551-1.207-.551-.446 0-.831.28-1.199.55-.201.15-.429.316-.647.403-.237.096-.508.14-.78.184-.445.07-.91.149-1.207.455s-.376.779-.446 1.199V5.4z"/><path d="M5.9 7.772c-.577 0-1.05-.472-1.05-1.05v-.07a1.044 1.044 0 0 1 .98-1.12 1.044 1.044 0 0 1 1.12.98v.15a1.044 1.044 0 0 1-.98 1.12H5.9zm4.2.447c-.577 0-1.05.472-1.05 1.05v.07a1.044 1.044 0 0 0 .98 1.12 1.045 1.045 0 0 0 1.12-.98V9.33a1.044 1.044 0 0 0-.98-1.12h-.07zm-.962-2.923L5.48 10.695h1.383l3.657-5.399z"/></svg>
                    <p>Carte fedeltà</p>
                </div>
                <div>
                    <svg width="1em" height="1em" aria-hidden="true" viewBox="0 0 16 16"><path d="M8 1.219A6.781 6.781 0 1 0 14.781 8 6.79 6.79 0 0 0 8 1.219m0 12.25A5.469 5.469 0 1 1 8 2.53a5.469 5.469 0 0 1 0 10.938zM7.344 7.29h1.312v3.334H7.344V7.291zm1.531-1.916a.875.875 0 1 1-1.75 0 .875.875 0 0 1 1.75 0"/></svg>
                    <p>Ti serve aiuto?</p>
                </div>
            </div>
            <div class="linea"></div>
            <div id="divmenuinferiore">
                <div>
                    <svg width="1em" height="1em" aria-hidden="true" viewBox="0 0 16 16"><path d="M14.072 9.802a2.35 2.35 0 0 0-1.697-.682c.06-.31.06-.627 0-.936l-1.75-5.872A1.514 1.514 0 0 0 9.102 1.22H6.355l.665 1.31h2.082a.23.23 0 0 1 .21.158l1.75 5.871a1.1 1.1 0 0 1-.559 1.296c-.152.076-.32.115-.49.113H8.63l-.7-2.503a1.54 1.54 0 0 0-1.487-1.164H2.75a1.54 1.54 0 0 0-1.531 1.532v3.447h1.33a2.35 2.35 0 0 0 .691 1.916 2.39 2.39 0 0 0 3.395 0 2.35 2.35 0 0 0 .691-1.916h2.625v.219a2.406 2.406 0 1 0 4.104-1.698h.018zM5.708 12.27a1.094 1.094 0 0 1-1.818-.456 1.06 1.06 0 0 1-.02-.533h2.135a1.06 1.06 0 0 1-.298.989zM2.53 9.969V7.834a.22.22 0 0 1 .219-.219h3.692a.236.236 0 0 1 .22.184l.603 2.17H2.531zm10.614 2.301a1.103 1.103 0 0 1-1.54 0 1.094 1.094 0 1 1 1.54 0"/></svg>
                    <p>Diventa rider</p>
                </div>
                <div>
                    <svg width="1em" height="1em" aria-hidden="true" viewBox="0 0 16 16"><path d="M12.375 2.094h-8.75a1.54 1.54 0 0 0-1.531 1.531v10.281h11.812V3.625a1.54 1.54 0 0 0-1.531-1.531m.219 10.5H8.656v-1.969H7.344v1.969H3.406V3.625a.22.22 0 0 1 .219-.219h8.75a.22.22 0 0 1 .219.219v7.875zm-3.719-7h1.75v1.312h-1.75zm-3.5 0h1.75v1.312h-1.75zm3.5 2.625h1.75V9.53h-1.75V8.22zm-3.5 0h1.75V9.53h-1.75V8.22z"/></svg>
                    <p>Just Eat for business</p>
                </div>
                <div>
                    <svg width="1em" height="1em" aria-hidden="true" viewBox="0 0 16 16"><path d="m13.863 3.485-1.19-1.015a1.5 1.5 0 0 0-.998-.376H4.351c-.365 0-.719.13-.997.367L2.155 3.485a2.57 2.57 0 0 0-.936 1.943 2.51 2.51 0 0 0 .875 1.88v6.598h11.812V7.31a2.52 2.52 0 0 0 .875-1.881 2.62 2.62 0 0 0-.918-1.943zm-5.05 9.109H7.187v-1.216a.814.814 0 0 1 1.628 0v1.216zm3.78 0h-2.467v-1.216a2.126 2.126 0 0 0-4.252 0v1.216H3.406V8a3.17 3.17 0 0 0 2.625-.621 3.13 3.13 0 0 0 3.903 0A3.17 3.17 0 0 0 12.559 8h.043zm-.297-5.889a1.75 1.75 0 0 1-1.793-.656H9.4A1.65 1.65 0 0 1 8 6.74a1.65 1.65 0 0 1-1.4-.691H5.497a1.75 1.75 0 0 1-1.75.656 1.38 1.38 0 0 1-1.216-1.277 1.24 1.24 0 0 1 .473-.928L4.21 3.459a.2.2 0 0 1 .14-.053h7.324a.2.2 0 0 1 .14.053l1.19 1.041a1.26 1.26 0 0 1 .464.945 1.38 1.38 0 0 1-1.173 1.26z"/></svg>
                    <p>Diventa partner</p>
                </div>
            </div>
        </div>
    </div>

    <header>
        <div class="maindiv">
            <div class="maindivleft">
                <div>
                    <h1>Ordina cibo e tanto altro</h1>
                    <h2>Ristoranti e spesa, a domicilio</h2>
                </div>
                <div class="search">
                    <input type="text" placeholder="Indirizzo completo" id="searchinput">
                    <button id="searchbutton">Cerca</button>
                </div>
            </div>
            <div class="maindivright">
                <div id="contenitoreslope">
                    <img src="<?php echo e(asset('img/slope.png')); ?>" alt="" id="slope">
                </div>
                <div id="contenitorepanino">
                    <img src="<?php echo e(asset('img/panino.png')); ?>" alt="panino">
                </div>
            </div>
        </div>
    </header>
    <section id="tipidicucina">
        <?php $__currentLoopData = $tipicucina; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cucina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div data-id_cucina="<?php echo e($cucina->id); ?>">
                <img src="<?php echo e(asset('svg/' . $cucina->path_icona)); ?>">
                <h2><?php echo e($cucina->nomecucina); ?></h2>
                <?php if(session()->has('email_utente')): ?>
                    <?php if(in_array($cucina->id, $cucinepiaciute ?? [])): ?>
                        <img src="<?php echo e(asset('svg/like.svg')); ?>" onclick="rimuovicucina(event)">
                    <?php else: ?>
                        <img src="<?php echo e(asset('svg/no_like.svg')); ?>" onclick="aggiungicucina(event)">
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    <div class="divcomeordinare">
        <div id="divcomeordinareslogan">
            <h3>Come ordinare</h3>
            <h2>È semplicissimo!</h2>
        </div>
        <div class="iconedivcomeordinare">
            <div>
                <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" fill="var(--xds-color-content-brand)" aria-hidden="true" class="c-pieIcon c-pieIcon--location-pin-large" style="margin-bottom:var(--xds-spacing-d)" viewBox="0 0 32 32"><path d="M24.75 26.5c0 2.406-4.533 3.5-8.75 3.5-4.218 0-8.75-1.094-8.75-3.5 0-1.313 1.339-2.214 3.15-2.765l1.426 1.435C9.875 25.625 9 26.237 9 26.5c0 .446 2.406 1.75 7 1.75s7-1.304 7-1.75c0-.262-.875-.875-2.826-1.33l1.426-1.435c1.811.551 3.15 1.453 3.15 2.765M8.746 19.605a10.255 10.255 0 1 1 14.508 0L16 26.859zm-1.251-7.254a8.48 8.48 0 0 0 2.485 6.02l6.02 6.02 6.02-6.02a8.513 8.513 0 1 0-14.525-6.02m4.13.149a4.376 4.376 0 1 1 8.751 0 4.376 4.376 0 0 1-8.751 0m1.75 0a2.624 2.624 0 1 0 5.248 0 2.624 2.624 0 0 0-5.248 0"/></svg>
                <h5>Indicaci la tua posizione</h5>
                <p>Ti mostreremo i negozi e i ristoranti della tua zona da cui puoi ordinare.</p>
            </div>
            <div>
                <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" fill="var(--xds-color-content-brand)" aria-hidden="true" class="c-pieIcon c-pieIcon--sandwich-large" style="margin-bottom:var(--xds-spacing-d)" viewBox="0 0 32 32"><path d="M28.836 15.125v1.75c-1.898 0-2.038.464-2.275 1.304a2.94 2.94 0 0 1-2.126 2.353 3.06 3.06 0 0 1-3.395-1.163c-.49-.517-.761-.788-1.234-.788-.288 0-.306 0-.542.569-.333.779-.875 2.091-3.264 2.091s-2.931-1.312-3.264-2.091c-.236-.525-.236-.525-.542-.525-.473 0-.744.271-1.234.787a3.06 3.06 0 0 1-3.395 1.164 2.94 2.94 0 0 1-2.126-2.354c-.236-.875-.376-1.303-2.275-1.303v-1.794c2.975 0 3.587 1.269 3.955 2.564.192.665.28.97.945 1.163s.98 0 1.619-.682a3.34 3.34 0 0 1 2.51-1.295 2.19 2.19 0 0 1 2.153 1.627c.29.665.438 1.033 1.654 1.033s1.365-.368 1.654-1.033a2.19 2.19 0 0 1 2.152-1.627 3.34 3.34 0 0 1 2.512 1.339c.638.673.875.875 1.618.682s.753-.499.945-1.164c.368-1.338.98-2.607 3.955-2.607M25.626 23a.875.875 0 0 1-.876.875H7.25A.875.875 0 0 1 6.375 23v-1.75h-1.75V23a2.625 2.625 0 0 0 2.625 2.625h17.5A2.625 2.625 0 0 0 27.375 23v-1.75h-1.75V23Zm-21-9.625v-1.531a5.583 5.583 0 0 1 8.583-4.594 5.46 5.46 0 0 1 2.984-.875c.99.003 1.96.266 2.817.761a5.556 5.556 0 0 1 8.365 4.708v1.53a.875.875 0 0 1-.875.876h-21a.875.875 0 0 1-.875-.875Zm1.75-.875h19.25v-.656a3.78 3.78 0 0 0-3.825-3.72 3.9 3.9 0 0 0-1.312.237c.31.38.565.802.761 1.251h-2.012a3.84 3.84 0 0 0-4.655-1.128q.413.525.7 1.128h-2.04A3.86 3.86 0 0 0 10.2 8.125a3.78 3.78 0 0 0-3.824 3.719z"/></svg>
                <h5>Trova ciò che desideri</h5>
                <p>Cerca articoli o piatti, locali o cucine.</p>
            </div>
            <div>
                <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" fill="var(--xds-color-content-brand)" aria-hidden="true" class="c-pieIcon c-pieIcon--food-ready-large" style="margin-bottom:var(--xds-spacing-d)" viewBox="0 0 32 32"><path d="m9.376 13.996 1.374 1.129A7 7 0 0 1 16 12.719v-1.75a8.75 8.75 0 0 0-6.624 3.027"/><path d="M13.874 21.25c.06-.596.186-1.183.376-1.75H5.937a10.054 10.054 0 0 1 18.585-5.329 8 8 0 0 1 2.564 1.304 11.83 11.83 0 0 0-8.951-7.586c.316-.442.487-.97.49-1.514a2.625 2.625 0 0 0-5.25 0c.003.543.174 1.072.49 1.514A11.83 11.83 0 0 0 4.187 19.5H2.875v5.25H14.25a9 9 0 0 1-.385-1.75h-9.24v-1.75zM16 5.5a.875.875 0 1 1 0 1.75.875.875 0 0 1 0-1.75M21.285 22.764l-1.199-1.19-1.233 1.233 2.432 2.433 4.113-4.121-1.234-1.234z"/><path d="M28.25 19.675a6.9 6.9 0 0 0-1.794-2.511 6.6 6.6 0 0 0-1.846-1.12 6.5 6.5 0 0 0-2.485-.482 6.54 6.54 0 0 0-4.288 1.602 6.8 6.8 0 0 0-1.855 2.625 6.8 6.8 0 0 0-.393 1.75v.551a6.562 6.562 0 1 0 12.66-2.415Zm-6.125 7.262a4.82 4.82 0 0 1-4.813-4.812v-.551a4.8 4.8 0 0 1 .552-1.75q.28-.47.647-.875a4.804 4.804 0 0 1 7.158 0q.366.406.647.875c.295.542.483 1.136.551 1.75v.551a4.82 4.82 0 0 1-4.742 4.813Z"/></svg>
                <h5>Ordina con consegna o ritiro al locale</h5>
                <p>Ti terremo aggiornato sullo stato del tuo ordine.</p>
            </div>
        </div>
    </div>
    <section class="sectionapplicazione">
        <div class="divapplicazione">
            <div id="divapplicazioneleft">
                <div>
                    <h2>Scarica l'app</h2>
                </div>
                <div>
                    <p>Il tuo piatto preferito è a portata di click!</p>
                </div>
                <div>
                    <img src="<?php echo e(asset('img/appstore.png')); ?>" alt="" id="appstore">
                    <img src="<?php echo e(asset('img/googleplay.png')); ?>" alt="" id="playstore">
                </div>
            </div>
            <div id="divapplicazioneright">
                <img src="<?php echo e(asset('img/apptelefono.png')); ?>" alt="" id="apptelefono">
            </div>
        </div>
    </section>
    <section class="dicosahaivogliasection">
        <div class="slogan">
            <p>Just Eat</p>
            <h2>Di cosa hai voglia?</h2>
        </div>
        <div class="boxpeculiarita">
            <div class="box">
                <svg xmlns="http://www.w3.org/2000/svg" role="presentation" focusable="false" fill="var(--xds-color-content-brand)" viewBox="0 0 16 16" class="c-pieIcon c-pieIcon--ribbon-heart" width="40" height="40"><path d="M13.696 11.955a7.24 7.24 0 0 1-1.522-2.013c.096-.308.144-.63.14-.953a2.08 2.08 0 0 1 .061-.578 2.51 2.51 0 0 1 .35-.411 2.074 2.074 0 0 0 .752-1.4 2.058 2.058 0 0 0-.752-1.391 2.51 2.51 0 0 1-.35-.412 2.124 2.124 0 0 1-.053-.577 2.048 2.048 0 0 0-.454-1.47 2.03 2.03 0 0 0-1.488-.438 2.39 2.39 0 0 1-.569-.06c-.158-.105-.3-.232-.42-.377A2.039 2.039 0 0 0 8 1.131a2.039 2.039 0 0 0-1.391.744 1.916 1.916 0 0 1-.42.35 2.39 2.39 0 0 1-.569.061 2.03 2.03 0 0 0-1.487.438 2.047 2.047 0 0 0-.447 1.487c.007.198-.014.395-.061.586-.102.15-.219.288-.35.412A2.056 2.056 0 0 0 2.531 6.6 2.074 2.074 0 0 0 3.284 8c.13.124.248.262.35.411.044.19.062.384.052.578-.004.323.044.645.14.953a7.237 7.237 0 0 1-1.522 2.013l-.648.604 3.947 2.31.358-.368a11.464 11.464 0 0 0 1.75-2.476c.1.023.203.038.306.044a1.85 1.85 0 0 0 .307-.044c.47.9 1.06 1.732 1.75 2.476l.358.368 3.947-2.31-.683-.604ZM4.23 6.119c.253-.235.46-.513.612-.823.116-.337.17-.693.158-1.05a1.96 1.96 0 0 1 .061-.577 1.75 1.75 0 0 1 .586-.044c.357.01.713-.042 1.05-.158.312-.152.591-.363.823-.62.138-.159.3-.295.481-.403.179.103.341.233.481.385.232.258.511.469.823.621.337.115.693.168 1.05.157.194-.01.388.008.577.053.057.19.08.388.07.586a2.95 2.95 0 0 0 .158 1.05c.152.31.36.588.612.823.123.131.385.393.385.481 0 .087-.262.359-.385.481a2.966 2.966 0 0 0-.612.875A2.95 2.95 0 0 0 11 9.006c.008.195-.012.39-.061.578a1.75 1.75 0 0 1-.586.061 2.975 2.975 0 0 0-1.05.157 2.687 2.687 0 0 0-.823.622c-.131.122-.393.376-.481.376-.088 0-.35-.254-.481-.376a2.687 2.687 0 0 0-.823-.674 2.975 2.975 0 0 0-1.05-.158 2.013 2.013 0 0 1-.577-.052 1.75 1.75 0 0 1-.07-.586 2.949 2.949 0 0 0-.158-1.05 2.966 2.966 0 0 0-.612-.875c-.123-.123-.385-.385-.385-.482 0-.096.262-.297.385-.428Zm1.146 7.079-1.549-.876A8.369 8.369 0 0 0 4.85 10.87c.26.053.523.076.788.07.191-.007.383.014.568.061.149.089.284.198.403.324-.34.668-.754 1.296-1.234 1.873Zm5.25 0a10.045 10.045 0 0 1-1.234-1.9c.119-.126.254-.235.403-.323.185-.047.377-.068.569-.061.264.006.528-.018.787-.07.289.519.632 1.006 1.024 1.452l-1.549.902Z"></path><path d="M8 8.656 6.521 7.125a.998.998 0 0 1 .295-1.58.875.875 0 0 1 1.009.215L8 5.926l.175-.166a.875.875 0 0 1 .647-.28.875.875 0 0 1 .657.28.998.998 0 0 1 0 1.365L8 8.656Z"></path></svg>
                <h4>Programmi fedeltà</h4>
                <div class="markedmessagecontainer">
                    <div class="markedmessage">
                        <svg viewBox="0 0 16 16" width="1em" height="1em" role="presentation" focusable="false" aria-hidden="true"><path d="M5.865 12.489a1.217 1.217 0 01-.875-.385L1.875 8.656l.98-.875 3.028 3.369 7.253-7.822.963.875-7.35 7.875a1.216 1.216 0 01-.875.385l-.009.026z"></path></svg>
                        <span><a href="" class="highlight">Ricevi i timbri</a>, promozioni, sconti, novità e molto altro tramite newsletter e pagine social</span>
                    </div>
                </div>
            </div>
            <div class="box">
                <svg xmlns="http://www.w3.org/2000/svg" role="presentation" focusable="false" fill="var(--xds-color-content-brand)" viewBox="0 0 16 16" class="c-pieIcon c-pieIcon--review" width="40" height="40"><path d="M12.375 1.219h-8.75A1.54 1.54 0 0 0 2.094 2.75v7.875a1.54 1.54 0 0 0 1.531 1.531h1.628L8 14.904l2.748-2.748h1.627a1.54 1.54 0 0 0 1.531-1.531V2.75a1.54 1.54 0 0 0-1.531-1.531Zm.219 9.406a.219.219 0 0 1-.219.219h-2.17L8 13.049l-2.205-2.205h-2.17a.219.219 0 0 1-.219-.219V2.75a.219.219 0 0 1 .219-.219h8.75a.219.219 0 0 1 .219.219v7.875ZM8.814 5.83l1.82.263L9.32 7.379l.306 1.811L8 8.341l-1.628.875.307-1.811-1.304-1.313 1.82-.262L8 4.185l.814 1.645Z"></path></svg>
                <h4>La nostra promessa</h4>
                <div class="markedmessagecontainer">
                    <div class="markedmessage">
                        <svg viewBox="0 0 16 16" width="1em" height="1em" role="presentation" focusable="false" aria-hidden="true"><path d="M5.865 12.489a1.217 1.217 0 01-.875-.385L1.875 8.656l.98-.875 3.028 3.369 7.253-7.822.963.875-7.35 7.875a1.216 1.216 0 01-.875.385l-.009.026z"></path></path></svg>
                        <span>Servizio eccellente</span>
                    </div>
                    <div class="markedmessage">
                        <svg viewBox="0 0 16 16" width="1em" height="1em" role="presentation" focusable="false" aria-hidden="true"><path d="M5.865 12.489a1.217 1.217 0 01-.875-.385L1.875 8.656l.98-.875 3.028 3.369 7.253-7.822.963.875-7.35 7.875a1.216 1.216 0 01-.875.385l-.009.026z"></path></svg>
                        <span>Recensioni autentiche</span>
                    </div>
                </div>
            </div>
            <div class="box">
                <svg xmlns="http://www.w3.org/2000/svg" role="presentation" focusable="false" fill="var(--xds-color-content-brand)" viewBox="0 0 16 16" class="c-pieIcon c-pieIcon--offer-star" width="40" height="40"><path d="M13.871 6.355a2.456 2.456 0 0 1-.472-.586c-.07-.26-.1-.528-.088-.796a2.467 2.467 0 0 0-.516-1.75 2.467 2.467 0 0 0-1.75-.517 2.626 2.626 0 0 1-.796-.087 2.283 2.283 0 0 1-.578-.473A2.45 2.45 0 0 0 8 1.22a2.45 2.45 0 0 0-1.654.875c-.165.188-.36.347-.577.472-.26.07-.528.1-.796.088a2.415 2.415 0 0 0-1.75.516 2.467 2.467 0 0 0-.517 1.75c.012.268-.018.537-.087.796a2.459 2.459 0 0 1-.473.587A2.415 2.415 0 0 0 1.22 8a2.415 2.415 0 0 0 .875 1.645c.186.17.346.368.472.586.07.26.1.528.088.796a2.467 2.467 0 0 0 .516 1.75c.496.39 1.122.575 1.75.517.268-.012.537.018.796.087.217.125.412.285.578.473a2.45 2.45 0 0 0 1.654.875 2.45 2.45 0 0 0 1.653-.875c.166-.188.36-.348.578-.473.26-.07.528-.099.796-.087a2.415 2.415 0 0 0 1.75-.517c.39-.495.574-1.122.516-1.75a2.621 2.621 0 0 1 .088-.796c.126-.218.286-.416.472-.586A2.415 2.415 0 0 0 14.676 8a2.415 2.415 0 0 0-.805-1.645Zm-.936 2.38a3.37 3.37 0 0 0-.753 1.015A3.503 3.503 0 0 0 12 11.019a1.89 1.89 0 0 1-.132.875 1.89 1.89 0 0 1-.875.131c-.43-.017-.86.045-1.268.184a3.367 3.367 0 0 0-.998.752c-.245.236-.551.534-.735.534-.183 0-.49-.297-.735-.534a3.368 3.368 0 0 0-1.006-.779A3.503 3.503 0 0 0 4.981 12a1.89 1.89 0 0 1-.875-.132 1.89 1.89 0 0 1-.131-.875 3.503 3.503 0 0 0-.158-1.242 3.369 3.369 0 0 0-.752-.998c-.236-.245-.534-.55-.534-.735 0-.183.298-.49.534-.734.314-.294.57-.644.752-1.033a3.503 3.503 0 0 0 .184-1.269 1.89 1.89 0 0 1 .131-.875 1.89 1.89 0 0 1 .876-.131 3.503 3.503 0 0 0 1.242-.158c.377-.186.715-.441.997-.752.245-.236.552-.534.736-.534.183 0 .49.298.734.534.294.314.644.57 1.033.752a3.503 3.503 0 0 0 1.269.184 1.89 1.89 0 0 1 .875.131c.112.278.157.578.131.876a3.503 3.503 0 0 0 .157 1.242c.187.377.442.715.753.997.236.245.534.552.534.736 0 .183-.298.507-.534.752ZM10.73 8A4.821 4.821 0 0 0 8 10.73 4.821 4.821 0 0 0 5.27 8 4.821 4.821 0 0 0 8 5.27 4.821 4.821 0 0 0 10.73 8Z"></path></svg>
                <h4>I tuoi vantaggi</h4>
                <div class="markedmessagecontainer">
                    <div class="markedmessage">
                        <svg viewBox="0 0 16 16" width="1em" height="1em" role="presentation" focusable="false" aria-hidden="true"><path d="M5.865 12.489a1.217 1.217 0 01-.875-.385L1.875 8.656l.98-.875 3.028 3.369 7.253-7.822.963.875-7.35 7.875a1.216 1.216 0 01-.875.385l-.009.026z"></path></svg>
                        <span>Oltre 28.000 locali tra cui scegliere</span>
                    </div>
                    <div class="markedmessage">
                        <svg viewBox="0 0 16 16" width="1em" height="1em" role="presentation" focusable="false" aria-hidden="true"><path d="M5.865 12.489a1.217 1.217 0 01-.875-.385L1.875 8.656l.98-.875 3.028 3.369 7.253-7.822.963.875-7.35 7.875a1.216 1.216 0 01-.875.385l-.009.026z"></path></svg>
                        <span>Paga online o in contanti</span>
                    </div>
                    <div class="markedmessage">
                        <svg viewBox="0 0 16 16" width="1em" height="1em" role="presentation" focusable="false" aria-hidden="true"><path d="M5.865 12.489a1.217 1.217 0 01-.875-.385L1.875 8.656l.98-.875 3.028 3.369 7.253-7.822.963.875-7.35 7.875a1.216 1.216 0 01-.875.385l-.009.026z"></path></svg>
                        <span>Ordina ovunque, in qualsiasi momento e con qualsiasi dispositivo</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="recensionisito">
        <?php $__currentLoopData = $recensioni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recensione): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <h3><?php echo e($recensione->titolo_recensione); ?></h3>
                <p><?php echo e($recensione->descrizione); ?></p>
                <h4><?php echo e($recensione->autore); ?></h4>
                <h2><?php echo e($recensione->voto); ?>/10</h2>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script defer src="<?php echo e(asset('js/homepage.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/gestione_like_cucina.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\anima\Desktop\hw2\resources\views/homepage.blade.php ENDPATH**/ ?>