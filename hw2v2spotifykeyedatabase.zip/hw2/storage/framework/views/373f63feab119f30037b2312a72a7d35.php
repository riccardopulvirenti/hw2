
<?php $__env->startSection('title','Just Eat | Login'); ?>
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div id="contenitoreform">
        <form method="POST" action="/login" name='login' id="form-login">
        <?php echo csrf_field(); ?>
            <div>
                <label>Email</label>
                <input type='email' name='email' id="email" required>
            </div>
            <div>
                <label>Password</label>
                <input type='password' name='password' id="password" required>
            </div>
            <div>
                <div>
                    <input type="submit" value="Accedi">
                </div>
                
            </div>
        </form>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Ricky\Desktop\hw2\resources\views/login.blade.php ENDPATH**/ ?>