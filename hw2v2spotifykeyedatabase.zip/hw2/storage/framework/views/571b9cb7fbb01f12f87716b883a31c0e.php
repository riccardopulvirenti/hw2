<div id="contenitorelogo">
    <a id="a_logo" href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(asset('svg/logo.svg')); ?>" alt="Logo">
    </a>
</div>

<div class="rightnav">
    <a id="bottonecercacibo" href="<?php echo e(url('cercacibo')); ?>">
        <img src="<?php echo e(asset('svg/food.svg')); ?>" alt="Cibo">
        <span>Cibo</span>
    </a>

    

    <a href="<?php echo e(url('ristoranti')); ?>">
        <img src="<?php echo e(asset('svg/partner.svg')); ?>" alt="Ristoranti">
        <span>Ristoranti</span>
    </a>

    <?php if(session()->has('email_utente')): ?>
        <a href="<?php echo e(url('informazioni_utente')); ?>">
            <img src="<?php echo e(asset('svg/informazioni.svg')); ?>" alt="Informazioni utente">
            <span>Info Utente</span>
        </a>

        <a href="<?php echo e(url('piattipreferiti')); ?>">
            <img src="<?php echo e(asset('svg/favourite.svg')); ?>" alt="Piatti preferiti">
            <span>Piatti preferiti</span>
        </a>
        <a href="<?php echo e(url('logout')); ?>">
            <img src="<?php echo e(asset('svg/logout.svg')); ?>" alt="Logout">
            <span>Logout</span>
        </a>

        <a href="<?php echo e(url('carrello')); ?>">
            <img src="<?php echo e(asset('svg/carrello.svg')); ?>" alt="Carrello">
            <span>Carrello</span>
        </a>
    <?php else: ?>
        <a id="login-page-button" href="<?php echo e(url('login')); ?>">
            <img src="<?php echo e(asset('svg/person.svg')); ?>" alt="Login">
            <span>Accedi</span>
        </a>

        <a id="signup-page-button" href="<?php echo e(url('signup')); ?>">
            <img src="<?php echo e(asset('svg/signup.svg')); ?>" alt="Registrati">
            <span>Registrati</span>
        </a>
    <?php endif; ?>

    

    <a>
        <img src="<?php echo e(asset('svg/italy.svg')); ?>" alt="Lingua">
    </a>

    <a id="idmenubutton">
        <img src="<?php echo e(asset('svg/menu.svg')); ?>" alt="Menu">
    </a>
    
</div>


<?php /**PATH C:\Users\Ricky\Desktop\hw2\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>