
<?php $__env->startSection('title'); ?>
    Just Eat | Menu <?php echo e($inforistorante['nome_ristorante']); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="informazioni_ristorante">
        <h3>Nome ristorante: <?php echo e($inforistorante['nome_ristorante']); ?></h3>
        <h4>Tipologia ristorante: <?php echo e($inforistorante['tipologia_ristorante']); ?></h4>
        <h4>Provincia ristorante: <?php echo e($inforistorante['provincia_ristorante']); ?></h4>
        <div>
            <?php for($i = 0; $i < $inforistorante['stelle_ristorante']; $i++): ?>
                <img src="<?php echo e(asset('svg/favourite.svg')); ?>" alt="stella">
            <?php endfor; ?>
        </div>
    </div>

    <div id="piatti_ristorante">
        <?php $__currentLoopData = $piatti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piatto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="pietanza" data-id_piatto="<?php echo e($piatto['id_piatto']); ?>">
                <p><strong><?php echo e($piatto['nome_piatto']); ?></strong></p>
                <p><?php echo e(number_format($piatto['prezzo'], 2, ',', '.')); ?> €</p>
                
                <?php if(session()->has('email_utente')): ?>
                    
                        <?php if(in_array($piatto['id_piatto'], $piattinelcarrello ?? [])): ?>
                            <form method="POST" action="<?php echo e(route('rimuovidalcarrello')); ?>">
                            <?php echo csrf_field(); ?>
                                <input type="hidden" name="id_piatto" value="<?php echo e($piatto['id_piatto']); ?>">
                                <input type="hidden" name="id_ristorante" value="<?php echo e($piatto['pivot']['id_ristorante']); ?>">
                                <button type="submit">
                                    <img src=<?php echo e(asset('svg/aggiunto-al-carrello.svg')); ?>>
                                </button>
                            </form>
                        <?php else: ?>
                            <form method="POST" action="<?php echo e(route('aggiungialcarrello')); ?>">
                            <?php echo csrf_field(); ?>
                                <input type="hidden" name="id_piatto" value="<?php echo e($piatto['id_piatto']); ?>">
                                <input type="hidden" name="id_ristorante" value="<?php echo e($piatto['pivot']['id_ristorante']); ?>">
                                <button type="submit">
                                    <img src=<?php echo e(asset('svg/aggiungi-al-carrello.svg')); ?>>
                                </button>
                            </form>
                        <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('css/mostramenuristorante.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\anima\Desktop\hw2\resources\views/mostramenuristorante.blade.php ENDPATH**/ ?>