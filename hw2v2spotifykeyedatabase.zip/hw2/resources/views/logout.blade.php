
<form id="logout-form" action="/logout" method="POST">
    @csrf
</form>

<script>
    document.getElementById('logout-form').submit();
</script>
